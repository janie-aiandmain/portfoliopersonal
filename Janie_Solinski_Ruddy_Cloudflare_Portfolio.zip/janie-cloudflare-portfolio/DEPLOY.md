# Deploy this portfolio to Cloudflare

## Recommended: GitHub → Cloudflare Workers Builds

1. Create a new GitHub repository (for example `janie-portfolio`).
2. Upload the **contents** of this project folder to the repository root. Make sure `wrangler.jsonc`, `package.json`, and the `public/` folder are at the top level.
3. In Cloudflare, open **Workers & Pages**.
4. Choose **Create application**.
5. Under **Import a repository**, choose **Get started**.
6. Connect GitHub if needed, select your portfolio repository, and continue.
7. Cloudflare should detect the included Wrangler configuration. The deploy command can remain the default: `npx wrangler deploy`.
8. Choose **Save and Deploy**.
9. Test the `workers.dev` URL Cloudflare provides.
10. When the site looks right, open the Worker → **Settings** → add your **Custom Domain**.

Because this project already includes a valid `wrangler.jsonc`, Cloudflare does not need to guess the static-assets configuration.

## CLI alternative

From the project folder:

```bash
npm install
npx wrangler login
npm run deploy
```

## Ongoing edits

With GitHub connected to Workers Builds, edit a file in the repository and push/commit it. Cloudflare can automatically build and deploy the new version.

## Main files to edit

- `public/index.html` — homepage
- `public/about.html` — About
- `public/case-studies.html` — case study directory
- `public/case-studies/*.html` — individual case studies
- `public/public-service.html` — board/public-service page
- `public/artifacts.html` — operating frameworks
- `public/contact.html` — contact page
- `public/assets/styles.css` — design system
